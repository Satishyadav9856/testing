import React from 'react';
import Layout from '../../components/Layout';
import { SectionTitle, Paragraph } from '../../styles';
import { EducationItem, Institution, Degree } from './styles';

const Education = ({ user }) => {
  return (
    <Layout user={user}>
      <div>
        <SectionTitle>Education</SectionTitle>
        <ul>
          
            <EducationItem >
              <Institution>Feroze Gandhi Institute OF Engineering & Technology</Institution>
              <div>
                <Degree>
                  Bachelor of Technology (Hons.)
                </Degree>
                <span>  </span>
                <span>
                  
                </span>
              </div>
              <Paragraph> Graduate Year 2014 to 2018</Paragraph>
            </EducationItem>
         
        </ul>
      </div>
    </Layout>
  );
};

export default Education;
