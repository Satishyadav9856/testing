import Education from './Education'
export default Education
