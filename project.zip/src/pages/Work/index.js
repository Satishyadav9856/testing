import Work from './Work'
export default Work
