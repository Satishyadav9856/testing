import React from 'react';
import Layout from '../../components/Layout';
import { SectionTitle, Paragraph } from '../../styles';
import { WorkItem, WorkTitle, JobTitle } from './styles';

const Work = ({ user }) => {
  return (
    <Layout user={user}>
      <div>
        <SectionTitle>Work</SectionTitle>
        <ul>
          
            <WorkItem >
              <WorkTitle>UPPCL</WorkTitle>
              <div><br></br>
                <JobTitle>Assistant Engineer</JobTitle> <span></span>
                <span><br></br></span>
                <span><br></br>
                 Working from  2019 to till today
                </span>
              </div>
              <Paragraph>Information & Technology</Paragraph>
            </WorkItem>
          
        </ul>
      </div>
    </Layout>
  );
};

export default Work;
