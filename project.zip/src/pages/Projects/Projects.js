import React from 'react';
import Layout from '../../components/Layout';
import { SectionTitle, Pill } from '../../styles';
import { ProjectItem, ProjectTitle, SkillContainer } from './styles';

const Projects = ({ user }) => {
  return (
    <Layout user={user}>
      <div>
        <SectionTitle>Projects</SectionTitle>
        <ul>
          
            <ProjectItem >
              <ProjectTitle>E-Commerce Website</ProjectTitle>
              <p>Website for Engineers purchase of tools and Equipments</p>

              <SkillContainer>
                
                  <Pill >PHP</Pill>
                  <Pill >Javascript</Pill>
                  <Pill >CSS</Pill>
                  <Pill >HTML</Pill>
                
              </SkillContainer>
            </ProjectItem>
          
        </ul>
        <ul>
          
            <ProjectItem >
              <ProjectTitle>Work Register in Railway</ProjectTitle>
              <p>Allotment of time and Pendency on different Department</p>

              <SkillContainer>
                
                  <Pill >PHP</Pill>
                  <Pill >Javascript</Pill>
                  <Pill >RDBMS</Pill>
                  <Pill >EXCEL</Pill>
                
              </SkillContainer>
            </ProjectItem>
          
        </ul>
      </div>
    </Layout>
  );
};

export default Projects;
