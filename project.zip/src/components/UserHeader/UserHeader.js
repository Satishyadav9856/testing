import React from 'react';
import './userheader.css';
import { useLocation } from 'react-router-dom';
import { ArrowRight16 } from '@carbon/icons-react';

import { HeaderContainer, Header, Image, ViewResumeLink } from './styles';

const UserHeader = () => {
  const location = useLocation();

  return (
    <HeaderContainer isHome={location.pathname === '/'}>
      <Header>
        <Image  id="img1"/>
       
       
        <div>
          <h2>SATISH Yadav</h2>
          <h4>
            <a
              href={`https://gitconnected.com/satishyadav9856`}
              target="_blank"
              rel="noreferrer noopener"
            >
              @SatishGITHUB-PAGE
            </a>
          </h4>
          <p>UPPCL:Assistant Engineer</p>
          <p>Email:satishsky1995@gmail.com</p>
          <p>Contact no: 878727####</p>
          <p>
            
            <a href target="_blank" rel="noreferrer noopener">
              
            </a>
          </p>
        </div>
      </Header>
      <div>
        <ViewResumeLink
          href={`https://gitconnected.com/satishyadav9856/resume`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <span>View Résumé</span>
          <ArrowRight16 />
        </ViewResumeLink>
      </div>
    </HeaderContainer>
  );
};

export default UserHeader;
